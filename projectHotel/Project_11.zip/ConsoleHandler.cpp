#include "ConsoleHandler.h"

void ConsoleHandler::open(string path)
{
    string PATH = path;
    
    if (f_inout.is_open())
    {
        cout << "Already opened file" << endl;
    }
    else
    {
        f_inout.open(PATH);

        if (!f_inout.is_open())
        {
            cout << "not a valid path"<<endl;
            return;
        }

        cout<<"Opened successfully"<<endl;

        char* token;
        token = strtok(&PATH[0], "\\");

        while (token != NULL)
        {
            f_fileName = token;
            token = strtok(NULL, "\\");
        }   
    } 
}

void ConsoleHandler::close()
{
    if(!f_inout.is_open())
    {
        cout << "Invalid command" << endl;
        cout << "Try opening a file first. The command is open." << endl;
    }
    else
    {
        cout << "Successfully closed " << f_fileName << endl;
        f_fileName = "";
        f_filePath = "";
        f_inout.close();
    }
}

void ConsoleHandler::save()
{
    if(!f_inout.is_open())
    {
        cout << "Invalid command" << endl;
        cout << "Try opening a file first. The command is open." << endl;
    }
    else
    {
        f_inout.clear();

        //f_inout << hotel;
        cout << "Successfully saved in "<< f_fileName << endl;
    }
}

void ConsoleHandler::saveAs(string path)
{
    string PATH = path;

    if(f_filePath == path)
    {   
        //f_inout << hotel;
    }
    else
    {
        fstream newstream(path);

        if(!newstream.is_open())
        {
            cout << "Invalid command" << endl;
            cout << "Try opening a file first. The command is open." << endl;
        }
        else
        {
            newstream.clear();

            //newstream << hotel;

            char* token;
            token = strtok(&PATH[0], "\\");
            string currentName;
            
            while (token != NULL)
            {
                currentName = token;
                token = strtok(NULL, "\\");
            } 

            cout << "Successfully saved in "<< currentName << endl;
            newstream.close();
        }
    }
}

void ConsoleHandler::exit()
{
    if(f_inout.is_open())
    {
        f_inout.close();
    }
    cout << "Exiting the program..." << endl;
    terminate();
}

void ConsoleHandler::help()
{
    cout << "The following commands are supported :\n"
         << "open <file>    opens <file>\n"
         << "close          closes currently opened file\n"
         << "save           saves the currently open file\n"
         << "saveas <file>  saves the currently open file in <file>\n"
         << "help           prints this information\n"
         << "exit           exists the program" << endl;
}

void ConsoleHandler::processCommand(string command)
{   
    string commandName, path = "";
    char* token;

    token = strtok(&command[0], " ");

    commandName = token;

    token = strtok(NULL, " ");

    if(token != NULL)
    {
        path = token;
    }

    if (commandName == "open")
    {  
        f_filePath = path;
        open(path);  
    }
    else if (commandName == "save")
    {
        save();
    }
    else if (commandName == "saveas")
    {
        if(path == "")
        {
            cout << "Invalid command.Try again!";
        }
        else
        {
            saveAs(path);
        }
    }
    else if (commandName == "close")
    {
        close();
    }
    else if (commandName == "help")
    {
        help();
    }
    else if (commandName == "exit")
    {
        exit();
    }
    else
    {
        cout << "Invalid command. Try again!" << endl;
    }
}