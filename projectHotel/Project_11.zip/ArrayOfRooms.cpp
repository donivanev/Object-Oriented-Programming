#include "ArrayOfRooms.h"

// bool ArrayOfRooms::contains(const char* name)
// {
//     for (int i = 0; i < size; i++)
//     {
//         if(strcmp(users[i].getName(), name) == 0) return true;
//     }
//     return false;
// }

int ArrayOfRooms::getSize()
{
    return rooms.size();
}

void ArrayOfRooms::add(int r, DateTime f, DateTime t, string n)
{
    Room newRoom(r, f, t, n);
    rooms.push_back(newRoom);
}

void ArrayOfRooms::check(DateTime date)
{
    for (int i = 0; i < rooms.size(); i++)
    {
        if (date > rooms.at(i).getDateFrom() && date < rooms.at(i).getDateTo())
        {
            cout << "Room number " << rooms.at(i).getNumber() << " is not free on this date" << endl;
        }
        else
        {
            cout << "Room number " << rooms.at(i).getNumber() << " is free on this date" << endl;
        }
    }
}

void ArrayOfRooms::release(int number)
{
    for (int i = 0; i < rooms.size(); i++)
    {
        if (rooms.at(i).getNumber() == number)
        {
            rooms.at(i) = Room(rooms.at(i).getNumber(), DateTime(), DateTime(), "");
        }
    }
}

void ArrayOfRooms::list(DateTime dateFrom, DateTime dateTo)
{
    vector<int> v;

    for (int i = 0; i < rooms.size(); i++)
    {
        v.push_back(rooms.at(i).getDateTo().getDay() - rooms.at(i).getDateFrom().getDay());
    }

    for (int i : v)
    {
        cout << i << endl;
    }
}

void ArrayOfRooms::findRoom(int number, DateTime dateFrom, DateTime dateTo)
{
    vector<int> v;


}

void ArrayOfRooms::findVIPRoom(int number, DateTime dateFrom, DateTime dateTo)
{
    vector<int> v;


}

void ArrayOfRooms::freeze(int number, DateTime dateFrom, DateTime dateTo, string note)
{
    vector<int> v;

    
}

void ArrayOfRooms::print()
{
    for (int i = 0; i < rooms.size(); i++)
    {
        cout << rooms[i];
    }
}

ostream& operator << (ostream& output, const ArrayOfRooms& rooms)
{
    for (int i = 0; i < rooms.rooms.size(); i++)
    {
        cout << rooms.rooms[i];
    }
    return output;
}